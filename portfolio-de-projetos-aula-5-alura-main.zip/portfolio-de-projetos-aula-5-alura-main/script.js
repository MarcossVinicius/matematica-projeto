// script.js
let num1, num2, respostaCerta, pontuacao = 0;
const operadores = ['+', '-', '*'];
const questaoElem = document.getElementById('questao');
const respostaElem = document.getElementById('resposta');
const resultadoElem = document.getElementById('resultado');
const pontuacaoElem = document.getElementById('pontuacao');
const personagemImg = document.getElementById('personagem-img');
const mensagemElem = document.getElementById('mensagem');

// Função para gerar uma nova pergunta
function novaPergunta() {
    const operador = operadores[Math.floor(Math.random() * operadores.length)];
    num1 = Math.floor(Math.random() * 10) + 1;
    num2 = Math.floor(Math.random() * 10) + 1;

    switch (operador) {
        case '+':
            respostaCerta = num1 + num2;
            break;
        case '-':
            respostaCerta = num1 - num2;
            break;
        case '*':
            respostaCerta = num1 * num2;
            break;
    }

    questaoElem.textContent = `Quanto é ${num1} ${operador} ${num2}?`;
    respostaElem.value = '';
    respostaElem.focus();
}

// Função para verificar a resposta
function verificarResposta() {
    const respostaUsuario = parseInt(respostaElem.value);

    if (respostaUsuario === respostaCerta) {
        pontuacao++;
        // Cebolinha feliz
        personagemImg.src = "cebolinha_feliz.png";
        mensagemElem.textContent = "Muito bem! Continue assim!";
        resultadoElem.textContent = '✅ Correto!';
        resultadoElem.style.color = 'green';
    } else {
        // Cebolinha triste
        personagemImg.src = "";
        mensagemElem.textContent = "Não desista, a próxima você vai conseguir!";
        resultadoElem.textContent = '❌ Tente novamente!';
        resultadoElem.style.color = 'red';
    }

    pontuacaoElem.textContent = `Pontuação: ${pontuacao}`;
    setTimeout(novaPergunta, 1500); // Nova pergunta após 1,5 segundos
}

// Iniciar o jogo com a primeira pergunta
novaPergunta();
