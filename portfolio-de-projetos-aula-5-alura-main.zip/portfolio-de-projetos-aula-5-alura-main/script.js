let pontuacao = 0;
let questaoAtual = 0;
const questoes = [
    { pergunta: "Quanto é 5 + 3?", resposta: 8 },
    { pergunta: "Quanto é 10 - 4?", resposta: 6 },
    { pergunta: "Quanto é 7 x 2?", resposta: 14 },
    { pergunta: "Quanto é 12 ÷ 4?", resposta: 3 }
];

function exibirQuestao() {
    if (questaoAtual < questoes.length) {
        document.getElementById("questao").textContent = questoes[questaoAtual].pergunta;
    } else {
        document.getElementById("questao").textContent = "Fim do jogo! Sua pontuação final é: " + pontuacao;
        document.getElementById("resposta").disabled = true; // Desabilitar o campo de resposta
        document.querySelector("button").disabled = true;   // Desabilitar o botão
    }
}

function verificarResposta() {
    const respostaUsuario = parseInt(document.getElementById("resposta").value);
    const respostaCorreta = questoes[questaoAtual].resposta;
    
    if (respostaUsuario === respostaCorreta) {
        pontuacao++;
        document.getElementById("resultado").textContent = "Resposta correta!";
    } else {
        document.getElementById("resultado").textContent = "Resposta incorreta! Tente novamente.";
    }
    
    document.getElementById("pontuacao").textContent = "Pontuação: " + pontuacao;
    
    // Envia os dados para o servidor
    fetch('http://localhost:3000/registrar', {  // Certifique-se de que o servidor esteja rodando na porta 3000
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            aluno: 'João', // Aqui pode ser um identificador único para o aluno, por exemplo
            respostaCorreta: respostaUsuario === respostaCorreta,
            pontuacaoAtual: pontuacao
        })
    }).then(response => response.json())
      .then(data => {
          console.log("Resposta registrada no servidor", data);
      })
      .catch(error => {
          console.error("Erro ao registrar resposta", error);
      });
    
    // Avançar para a próxima questão
    questaoAtual++;
    
    setTimeout(() => {
        document.getElementById("resposta").value = ""; // Limpar o campo de resposta
        document.getElementById("resultado").textContent = ""; // Limpar a mensagem de resultado
        exibirQuestao();
    }, 1000);
}

// Chama a função para exibir a primeira questão
exibirQuestao();
