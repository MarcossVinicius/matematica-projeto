const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Conectar ao banco de dados MongoDB
mongoose.connect('mongodb://localhost/jogo-matematica', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Conectado ao MongoDB'))
    .catch(err => console.log(err));

// Criar o schema de respostas dos alunos
const respostaSchema = new mongoose.Schema({
    aluno: String,
    respostaCorreta: Boolean,
    pontuacao: Number
});

const Resposta = mongoose.model('Resposta', respostaSchema);

app.use(bodyParser.json());

// Rota para receber os dados do aluno
app.post('/registrar', (req, res) => {
    const { aluno, respostaCorreta, pontuacaoAtual } = req.body;
    
    const novaResposta = new Resposta({
        aluno,
        respostaCorreta,
        pontuacao: pontuacaoAtual
    });
    
    novaResposta.save()
        .then(() => res.status(200).json({ message: 'Resposta registrada com sucesso!' }))
        .catch(err => res.status(500).json({ message: 'Erro ao registrar resposta', error: err }));
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
